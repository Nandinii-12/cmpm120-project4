import { BaseLevel } from "./BaseLevel.js";

export class Level2 extends BaseLevel {
    constructor() {
        super("Level2", "lvl2");
    }
}

//Untested